
"use strict";

let NumeralRomans = require('./NumeralRomans.js')
let RomanNumerals = require('./RomanNumerals.js')

module.exports = {
  NumeralRomans: NumeralRomans,
  RomanNumerals: RomanNumerals,
};
