// Auto-generated. Do not edit!

// (in-package roman_numerals.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class NumeralRomansRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.value = null;
    }
    else {
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NumeralRomansRequest
    // Serialize message field [value]
    bufferOffset = _serializer.int64(obj.value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NumeralRomansRequest
    let len;
    let data = new NumeralRomansRequest(null);
    // Deserialize message field [value]
    data.value = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'roman_numerals/NumeralRomansRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6dd7c3e2ac5f4efb95e3dafd2085a161';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NumeralRomansRequest(null);
    if (msg.value !== undefined) {
      resolved.value = msg.value;
    }
    else {
      resolved.value = 0
    }

    return resolved;
    }
};

class NumeralRomansResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.roman = null;
    }
    else {
      if (initObj.hasOwnProperty('roman')) {
        this.roman = initObj.roman
      }
      else {
        this.roman = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NumeralRomansResponse
    // Serialize message field [roman]
    bufferOffset = _serializer.string(obj.roman, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NumeralRomansResponse
    let len;
    let data = new NumeralRomansResponse(null);
    // Deserialize message field [roman]
    data.roman = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.roman.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'roman_numerals/NumeralRomansResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0c7b6683f56e93dbf4f7a5191a5c1e01';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string roman
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NumeralRomansResponse(null);
    if (msg.roman !== undefined) {
      resolved.roman = msg.roman;
    }
    else {
      resolved.roman = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: NumeralRomansRequest,
  Response: NumeralRomansResponse,
  md5sum() { return '806e807df0576f001baf8796260dd04d'; },
  datatype() { return 'roman_numerals/NumeralRomans'; }
};
