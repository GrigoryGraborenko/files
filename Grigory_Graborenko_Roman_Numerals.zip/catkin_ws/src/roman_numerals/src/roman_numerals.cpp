#include "ros/ros.h"
#include "roman_numerals/RomanNumerals.h"

#include <unordered_map>

/// no reason why this can't work for arbitrary values like a = 1, b = 17, c = 133
std::unordered_map<unsigned char, unsigned int> numeral_map = {
	{'i', 1}, {'I', 1}
	,{'v', 5}, {'V', 5}
	,{'x', 10}, {'X', 10}
	,{'l', 50}, {'L', 50}
	,{'c', 100}, {'C', 100}
	,{'d', 500}, {'D', 500}
	,{'m', 1000}, {'M', 1000}
};

unsigned int RomanNumeral(std::string str) {

	/*
	https://projecteuler.net/about=roman_numerals
	Numerals must be arranged in descending order of size.
	M, C, and X cannot be equalled or exceeded by smaller denominations.
	D, L, and V can each only appear once.
	*/

	/// pre-fill to ensure entries like DD without preceding M get detected as invalid
	std::map<unsigned int, unsigned int> value_sums;
	for(std::unordered_map<unsigned char, unsigned int>::const_iterator it = numeral_map.begin(); it != numeral_map.end(); it++) {
		value_sums[it->second] = 0;
	}

	/// turn letters into values, doing subtraction at the same time
	std::vector<unsigned int> values;
	for(std::string::iterator it = str.begin(); it != str.end(); it++) {
		unsigned int value = 0;
		try {
			value = numeral_map.at(*it);
		} catch(std::out_of_range err) {
			throw std::runtime_error(std::string("Invalid character"));
		}
		if((values.size() > 0) && (values.back() < value) && (values.back() != 0)) { /// subtraction rule
			values[values.size() - 1] = value - values.back();
			value = 0; /// set to zero to prevent subtractions cascading, poor old romans couldn't handle this kind of complexity
		}
		values.push_back(value);
	}

	/// creating histogram of different values, including composite subtraction values
	int previous_value = 0;
	for(std::vector<unsigned int>::iterator it = values.begin(); it != values.end(); it++) {
		if((*it) == 0) {
			continue; /// ignore gaps created by subtraction rule
		}
		if((previous_value > 0) && (previous_value < (*it))) {
			/// breaks descending order rule, post subtraction
			throw std::runtime_error(std::string("Breaks descending order rule"));
		}
		if(value_sums[*it] == 0) {
			value_sums[*it] = 0;
		}
		value_sums[*it] += *it;
		previous_value = *it;
	}

	/// sum the values up, while checking for the final rule
	int sum = 0;
	for(std::map<unsigned int, unsigned int>::iterator it = value_sums.begin(); it != value_sums.end(); it++) {
		if(sum >= it->first) {
			throw std::runtime_error(std::string("breaks the 'M, C, and X cannot be equalled or exceeded by smaller denominations.' rule"));
		}
		sum += it->second;
	}
	return sum;
}

bool convert(roman_numerals::RomanNumerals::Request &req, roman_numerals::RomanNumerals::Response &res) {
  std::string input = req.roman;
  ROS_INFO("request: x=%s", input.c_str());

  res.value = RomanNumeral(input);
  
  ROS_INFO("sending back response: [%ld]", (long int)res.value);
  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "roman_numerals_server");
  ros::NodeHandle n;

  ros::ServiceServer service = n.advertiseService("numeral_converter", convert);
  ROS_INFO("Ready to convert roman numerals.");
  ros::spin();

  return 0;
}
