#include "ros/ros.h"
#include "roman_numerals/NumeralRomans.h"

#include <unordered_map>

/// no reason why this can't work for arbitrary values like a = 1, b = 17, c = 133
std::unordered_map<unsigned char, unsigned int> numeral_map = {
	{'i', 1}, {'I', 1}
	,{'v', 5}, {'V', 5}
	,{'x', 10}, {'X', 10}
	,{'l', 50}, {'L', 50}
	,{'c', 100}, {'C', 100}
	,{'d', 500}, {'D', 500}
	,{'m', 1000}, {'M', 1000}
};

std::string NumeralRoman(unsigned int value) {

	std::map<unsigned int, unsigned char, std::greater<unsigned int>> letters;
	for(std::unordered_map<unsigned char, unsigned int>::const_iterator it = numeral_map.begin(); it != numeral_map.end(); it++) {
		if(it->first >= 97) { /// only use the upper case versions
			continue;
		}
		letters[it->second] = it->first;
	}

	std::string result;
	for(std::map<unsigned int, unsigned char, std::greater<unsigned int>>::const_iterator itA = letters.begin(); itA != letters.end(); itA++) {
		while(value >= itA->first) {
			value -= itA->first;
			result += itA->second;
		}

		std::map<unsigned int, unsigned char, std::greater<unsigned int>>::const_iterator itB = itA;
		while(true) {
			itB++;
			if(itB == letters.end()) {
				break;
			}
			unsigned int subtract_val = itA->first - itB->first;
			if(subtract_val > itB->first) { /// ensure you don't get something absurd like VX instead of V
				if(value >= subtract_val) {
					value -= subtract_val;
					result += itB->second;
					result += itA->second;
				}
				break;
			}
		}
	}

	return result;
}

bool convert(roman_numerals::NumeralRomans::Request &req, roman_numerals::NumeralRomans::Response &res) {
  unsigned int input = req.value;
  ROS_INFO("request: x=%ld", input);
  
  res.roman = NumeralRoman(input);
  //res.roman = std::string("MMMCXII");
  
  ROS_INFO("sending back response: [%s]", res.roman.c_str());
  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "numeral_romans_server");
  ros::NodeHandle n;

  ros::ServiceServer service = n.advertiseService("numeral_romans", convert);
  ROS_INFO("Ready to convert numbers into roman numerals.");
  ros::spin();

  return 0;
}
