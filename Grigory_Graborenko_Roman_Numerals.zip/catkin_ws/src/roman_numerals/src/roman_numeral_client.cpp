#include "ros/ros.h"
#include "roman_numerals/RomanNumerals.h"
#include "roman_numerals/NumeralRomans.h"
#include <cstdlib>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "roman_numeral_client");
  if (argc != 2)
  {
    ROS_INFO("usage: roman_numeral_client X");
    return 1;
  }

  ros::NodeHandle n;
  
  unsigned int input_num = atoll(argv[1]);
  if(input_num > 0) {
	  ros::ServiceClient client = n.serviceClient<roman_numerals::NumeralRomans>("numeral_romans");
	  roman_numerals::NumeralRomans srv;
	  srv.request.value = input_num;
	  if(client.call(srv)) {
		ROS_INFO("Output: %s", srv.response.roman.c_str());
	  } else {
		ROS_ERROR("Failed to call service numeral_romans");
		return 1;
	  }
	  return 0;
  }
  
  ros::ServiceClient client = n.serviceClient<roman_numerals::RomanNumerals>("numeral_converter");
  roman_numerals::RomanNumerals srv;
  std::string roman(argv[1]);
  srv.request.roman = roman;
  if(client.call(srv)) {
    ROS_INFO("Sum: %ld", (long int)srv.response.value);
  } else {
    ROS_ERROR("Failed to call service roman_numerals");
    return 1;
  }

  return 0;
}
